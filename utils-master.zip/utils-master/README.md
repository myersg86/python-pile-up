utils
=====

utilities for text manipulation (mostly python)
