import sys
import random
from os import linesep, path
from itertools import count, imap
from math import log
from operator import itemgetter
